BACKTEST SCANNER
================

REQUIREMENTS
------------
- Python must be installed on your computer
  Download: https://www.python.org/downloads/
  (Check "Add Python to PATH" during install)

HOW TO RUN
----------
1. Extract this zip folder anywhere on your computer
2. Double-click start.bat
3. Browser will open automatically to the app at http://localhost:5000

NOTES
-----
- API key is pre-loaded in the .env file
- To stop the app, close the terminal window that opens

TROUBLESHOOTING
---------------
- If browser doesn't open, manually go to http://localhost:5000
- If you get a pip error, open a terminal and run:
    pip install flask requests python-dotenv
  Then double-click start.bat again
