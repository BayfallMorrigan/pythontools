from flask import Flask, render_template, request, jsonify, Response
import csv
import io
from dotenv import load_dotenv
from backtest import (
    get_last_trading_days as get_trading_days,
    get_date_range,
    get_candles,
    scan_day
)

load_dotenv()
app = Flask(__name__)

# ── Last run cache for CSV export ──────────────────────────────────────────
last_run_signals = []

# ── Signal parameters — locked to backtest.py v5 defaults ──────────────────
EMA_CONSEC_RISING_MIN       = 4
EMA_SLOPE_PCT_MIN           = 0.003
EMA_SLOPE_PCT_MIN_2CANDLE   = 0.012
EMA_CONSEC_FALL_BEFORE_MAX  = 15
EMA_ACCEL_PCT_MIN           = -0.20
EMA9_CROSS_LOOKBACK         = 5
PRE_SIGNAL_BODY_CANDLES     = 8
PRE_SIGNAL_MIN_BODY_DOM     = 0.28
T1_BODY_RATIO_MIN           = 0.7
CONSEC_GREEN_MIN            = 1
ALLOW_FIRST_PULLBACK        = True
FIRST_PULLBACK_T1_ROC1_MIN  = 5.0
FIRST_PULLBACK_T1_VOL_RATIO = 2.0
PRICE_ABOVE_EMA_MIN_PCT     = 3.0
VWAP_GAP_MIN_PCT            = -5.0
VWAP_GAP_MAX_PCT            = 10.0
MIN_ABS_VOLUME              = 15000
COOLDOWN_MINUTES            = 20
MIN_VOL_SURGE_20            = 2.0
REQUIRE_POSITIVE_ROC1       = False


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/run", methods=["POST"])
def run_backtest():
    global last_run_signals
    data = request.json

    all_signals = []
    trading_days_set = set()

    # ── Pool mode: list of {ticker, date} pairs ──────────────────────────────
    pool = data.get("pool")
    if pool:
        pairs = []
        for entry in pool:
            ticker = entry.get("ticker", "").strip().upper()
            date   = entry.get("date", "").strip()
            if ticker and date:
                pairs.append((ticker, date))
                trading_days_set.add(date)

        for ticker, date in pairs:
            candles = get_candles(ticker, date)
            if not candles:
                continue
            signals = scan_day(
                ticker, date, candles,
                ema_consec_rising_min       = EMA_CONSEC_RISING_MIN,
                ema_slope_pct_min           = EMA_SLOPE_PCT_MIN,
                ema_slope_pct_min_2candle   = EMA_SLOPE_PCT_MIN_2CANDLE,
                ema_consec_fall_before_max  = EMA_CONSEC_FALL_BEFORE_MAX,
                ema_accel_pct_min           = EMA_ACCEL_PCT_MIN,
                ema9_cross_lookback         = EMA9_CROSS_LOOKBACK,
                pre_signal_body_candles     = PRE_SIGNAL_BODY_CANDLES,
                pre_signal_min_body_dom     = PRE_SIGNAL_MIN_BODY_DOM,
                t1_body_ratio_min           = T1_BODY_RATIO_MIN,
                consec_green_min            = CONSEC_GREEN_MIN,
                allow_first_pullback        = ALLOW_FIRST_PULLBACK,
                first_pullback_t1_roc1_min  = FIRST_PULLBACK_T1_ROC1_MIN,
                first_pullback_t1_vol_ratio = FIRST_PULLBACK_T1_VOL_RATIO,
                price_above_ema_min_pct     = PRICE_ABOVE_EMA_MIN_PCT,
                min_abs_volume              = MIN_ABS_VOLUME,
                cooldown_minutes            = COOLDOWN_MINUTES,
                require_positive_roc1       = REQUIRE_POSITIVE_ROC1,
                vwap_gap_min_pct            = VWAP_GAP_MIN_PCT,
                vwap_gap_max_pct            = VWAP_GAP_MAX_PCT,
                min_vol_surge_20            = MIN_VOL_SURGE_20,
            )
            all_signals.extend(signals)

        last_run_signals = all_signals
        return jsonify({
            "signals":      all_signals,
            "days_scanned": sorted(list(trading_days_set)),
            "total":        len(all_signals)
        })

    # ── Classic mode: tickers string + date range ────────────────────────────
    tickers = [t.strip().upper() for t in data.get("tickers", "").split(",") if t.strip()]

    start_date = data.get("start_date", "").strip()
    end_date   = data.get("end_date",   "").strip()
    days       = int(data.get("days", 1))

    trading_days = get_date_range(start_date, end_date) if start_date and end_date else get_trading_days(days)

    for date in trading_days:
        for ticker in tickers:
            candles = get_candles(ticker, date)
            if not candles:
                continue
            signals = scan_day(
                ticker, date, candles,
                ema_consec_rising_min       = EMA_CONSEC_RISING_MIN,
                ema_slope_pct_min           = EMA_SLOPE_PCT_MIN,
                ema_slope_pct_min_2candle   = EMA_SLOPE_PCT_MIN_2CANDLE,
                ema_consec_fall_before_max  = EMA_CONSEC_FALL_BEFORE_MAX,
                ema_accel_pct_min           = EMA_ACCEL_PCT_MIN,
                ema9_cross_lookback         = EMA9_CROSS_LOOKBACK,
                pre_signal_body_candles     = PRE_SIGNAL_BODY_CANDLES,
                pre_signal_min_body_dom     = PRE_SIGNAL_MIN_BODY_DOM,
                t1_body_ratio_min           = T1_BODY_RATIO_MIN,
                consec_green_min            = CONSEC_GREEN_MIN,
                allow_first_pullback        = ALLOW_FIRST_PULLBACK,
                first_pullback_t1_roc1_min  = FIRST_PULLBACK_T1_ROC1_MIN,
                first_pullback_t1_vol_ratio = FIRST_PULLBACK_T1_VOL_RATIO,
                price_above_ema_min_pct     = PRICE_ABOVE_EMA_MIN_PCT,
                min_abs_volume              = MIN_ABS_VOLUME,
                cooldown_minutes            = COOLDOWN_MINUTES,
                require_positive_roc1       = REQUIRE_POSITIVE_ROC1,
                vwap_gap_min_pct            = VWAP_GAP_MIN_PCT,
                vwap_gap_max_pct            = VWAP_GAP_MAX_PCT,
                min_vol_surge_20            = MIN_VOL_SURGE_20,
            )
            all_signals.extend(signals)

    last_run_signals = all_signals

    return jsonify({
        "signals":      all_signals,
        "days_scanned": trading_days,
        "total":        len(all_signals)
    })




@app.route("/export")
def export_csv():
    if not last_run_signals:
        return Response("No signals to export.", mimetype="text/plain", status=404)

    columns = [
        "ticker", "date", "time", "window",
        "close", "volume",
        "vol_surge_ratio", "range_expansion_ratio",
        "ema9", "ema20", "vwap",
        "ema9_vwap_gap_pct", "ema9_ema20_gap_pct",
        "ema9_above_ema20_candles",
        "ema9_slope_pct", "ema9_accel",
        "ema_consec_rising", "ema_consec_fall_before",
        "price_to_ema_pct",
        "avg_body_dom", "t1_body_ratio",
        "consec_green_before",
        "roc1", "roc3",
        "first_pullback",
    ]

    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    for sig in last_run_signals:
        writer.writerow({col: sig.get(col, "") for col in columns})

    out.seek(0)
    filename = f"backtest_signals.csv"
    return Response(
        out.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

if __name__ == "__main__":
    app.run(debug=True, port=5000)