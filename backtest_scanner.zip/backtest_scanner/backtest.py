import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, time
import pytz
from dotenv import load_dotenv
from polygon import RESTClient
import time as ttime

load_dotenv()
API_KEY = os.getenv("POLYGON_API_KEY")
client  = RESTClient(API_KEY)
ET      = pytz.timezone("America/New_York")

# ─────────────────────────────────────────
# STOCK POOL
# ─────────────────────────────────────────
STOCK_POOL = [
    "SPY", "AAPL", "GOOG", "MSFT", "AMZN", "META", "TSLA", "AMD",
    "GRUB", "BNAI", "NIO", "PLTR", "BRKA",
]

# ═══════════════════════════════════════════════════════════════════
# SIGNAL PARAMETERS  —  v9.0  (calibrated from signal_auditor output)
#
# Changes from v8.1:
#
#   R8  PRICE_ABOVE_EMA_MIN_PCT: 1.0 → 0.5
#       Blocked OPTT (0.982%) and WVE (0.723%). Both are fresh crosses
#       where price hasn't expanded yet — that's the point of entry.
#
#   R11 T1_BODY_RATIO_MIN: 0.7 → 0.3
#       Blocked WVE (0.391x). WVE is a slow institutional grind,
#       not a spike setup. 0.3 still requires some body presence.
#
#   R16 MIN_VOL_SURGE_20: 2.0 → 0.75
#       Blocked WVE (0.54x). WVE-type signals are low-float slow
#       grinds with steady volume — they don't spike 2x. 0.75 still
#       filters true dead candles.
#       NOTE: high-VWAP-gap bypass (>8% → 1.0x threshold) retained.
#
#   R1a VWAP_NEAR_CROSS_PCT (NEW): allow signals where EMA9 is within
#       0.5% BELOW VWAP but rising hard (CR>=5, slope>0.1%). Catches
#       the WVE 10:19 case where computed VWAP diverges slightly from
#       Webull's VWAP — the cross is real, our computation is ~0.15%
#       off. EMA9 must be trending toward VWAP, not falling away.
#
#   TIME WINDOW: premarket floor raised from 4:30 → 6:30am
#       HCTI fired a false signal at 4:34am — vol avg20 was only 6,687.
#       Deep premarket signals before 6:30am are nearly always noise
#       (thin books, wide spreads). Legit premarket signals on our
#       target universe happen 6:30-9:19am.
#       Session window unchanged: 9:35am-1:00pm.
#
#   MIN_BASELINE_VOL_20 (NEW): 10,000
#       The 20-candle average volume must be >= this floor before a
#       signal can fire. Catches the HCTI 4:34 false fire (avg20=6,687)
#       without touching any of the real signals (all had avg20 >> 10k).
#
#   INDEX_MIN_CANDLES: 23 → 12
#       BFLY and ALBT were skipped entirely because they only had 10-11
#       candles of history at signal time. They're early premarket
#       setups. 12 gives enough history for EMA9 to stabilize while
#       not throwing away early legitimate signals.
#       EMA_SLOW_PERIOD check removed from guard — EMA20 is context
#       only, not a gate, so it doesn't need 20 candles to be valid.
#
# ═══════════════════════════════════════════════════════════════════

EMA_PERIOD       = 9
EMA_SLOW_PERIOD  = 20

EMA9_CROSS_LOOKBACK         = 5
CROSS_PROXIMITY_PCT         = 2.0
CROSS_MAX_AGE               = 40
RAN_AWAY_MIN_GAP            = 3.0

# Allow signal when EMA9 is within this % BELOW VWAP but rising hard.
# Catches VWAP computation divergence from Webull on slow-grind crosses.
VWAP_NEAR_CROSS_PCT         = 0.5

EMA_CONSEC_RISING_MIN       = 3
EMA_SLOPE_PCT_MIN           = 0.003
EMA_SLOPE_PCT_MIN_2CANDLE   = 0.012
EMA_CONSEC_FALL_BEFORE_MAX  = 15
EMA_ACCEL_PCT_MIN           = -0.50

PRE_SIGNAL_BODY_CANDLES     = 8
PRE_SIGNAL_MIN_BODY_DOM     = 0.28
T1_BODY_RATIO_MIN           = 0.3       # was 0.7 → lowered to catch WVE-type grinds
T1_MUST_BE_GREEN            = True
CONSEC_GREEN_BEFORE_MIN     = 1
ALLOW_FIRST_PULLBACK        = True
FIRST_PULLBACK_T1_ROC1_MIN  = 5.0
FIRST_PULLBACK_T1_VOL_RATIO = 2.0

PRICE_ABOVE_EMA_MIN_PCT     = 0.5       # was 1.0 → lowered to catch fresh-cross entries
BROKE_LOW5_ALLOWED          = False

REQUIRE_POSITIVE_ROC1       = False

VWAP_GAP_MIN_PCT            = -5.0
VWAP_GAP_MAX_PCT            = 10.0

MIN_ABS_VOLUME              = 15000
MIN_VOL_SURGE_20            = 0.75      # was 2.0 → lowered to catch WVE-type slow grinds
MIN_BASELINE_VOL_20         = 10000     # NEW: avg20 must be >= this — blocks dead premarket noise

COOLDOWN_MINUTES            = 20

# Minimum candles needed before signals can fire.
# Lowered from ~23 to 12 to catch early premarket signals (BFLY, ALBT).
INDEX_MIN_CANDLES           = 12


# ─────────────────────────────────────────
# VALID TIME WINDOWS
# v9: premarket floor raised to 6:30am (was 4:30am)
# HCTI fired false at 4:34am — deep premarket is noise.
# Session window unchanged.
# ─────────────────────────────────────────
def is_valid_time(t):
    window1 = time(6, 30) <= t <= time(9, 19)
    window2 = time(9, 35) <= t <= time(13, 0)
    return window1 or window2


# ─────────────────────────────────────────
# TRADING DAYS
# ─────────────────────────────────────────
def get_last_trading_days(n=5):
    days = []
    dt   = datetime.now(ET)
    while len(days) < n:
        dt -= timedelta(days=1)
        if dt.weekday() < 5:
            days.append(dt.strftime("%Y-%m-%d"))
    return list(reversed(days))

def get_date_range(start_date, end_date):
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end   = datetime.strptime(end_date,   "%Y-%m-%d")
    days, dt = [], start
    while dt <= end:
        if dt.weekday() < 5:
            days.append(dt.strftime("%Y-%m-%d"))
        dt += timedelta(days=1)
    return days


# ─────────────────────────────────────────
# FETCH 1-MINUTE CANDLES
# ─────────────────────────────────────────
def get_candles(ticker, date):
    try:
        anchor   = ET.localize(datetime.strptime(f"{date} 04:00:00", "%Y-%m-%d %H:%M:%S"))
        end      = ET.localize(datetime.strptime(f"{date} 20:00:00", "%Y-%m-%d %H:%M:%S"))
        start_ms = int(anchor.timestamp() * 1000)
        end_ms   = int(end.timestamp()    * 1000)
        bars     = client.get_aggs(ticker, 1, "minute", start_ms, end_ms, limit=1000, adjusted=False)
        candles  = []
        for bar in bars:
            if bar.timestamp < start_ms or bar.timestamp > end_ms:
                continue
            ct = datetime.fromtimestamp(bar.timestamp / 1000, tz=ET)
            candles.append({
                "time":   ct,
                "open":   bar.open,
                "high":   bar.high,
                "low":    bar.low,
                "close":  bar.close,
                "volume": bar.volume,
            })
        ttime.sleep(12)
        return sorted(candles, key=lambda x: x["time"])
    except Exception as e:
        print(f"  Error fetching {ticker} on {date}: {e}")
        return []


# ─────────────────────────────────────────
# INDICATORS
# ─────────────────────────────────────────
def calculate_ema(prices, period):
    return pd.Series(prices).ewm(span=period, adjust=False).mean().values

def calculate_vwap(candles):
    cum_tp_vol = 0.0
    cum_vol    = 0.0
    vwap_vals  = []
    for c in candles:
        tp       = (c["high"] + c["low"] + c["close"]) / 3.0
        vol      = c["volume"] if c["volume"] > 0 else 0
        cum_tp_vol += tp * vol
        cum_vol    += vol
        vwap_vals.append(cum_tp_vol / cum_vol if cum_vol > 0 else tp)
    return vwap_vals

def calculate_indicators(candles):
    closes = [c["close"] for c in candles]
    highs  = [c["high"]  for c in candles]
    lows   = [c["low"]   for c in candles]
    bodies = [abs(c["close"] - c["open"]) for c in candles]

    ema9         = calculate_ema(closes, EMA_PERIOD)
    ema5         = calculate_ema(closes, 5)
    ema20        = calculate_ema(closes, EMA_SLOW_PERIOD)
    vwap         = calculate_vwap(candles)
    body_ma10    = pd.Series(bodies).rolling(10, min_periods=1).mean().values
    recent_low5  = pd.Series(lows).rolling(5,  min_periods=1).min().values
    recent_high5 = pd.Series(highs).rolling(5, min_periods=1).max().values

    return {
        "ema9":         ema9,
        "ema5":         ema5,
        "ema20":        ema20,
        "vwap":         vwap,
        "body_ma10":    body_ma10,
        "recent_low5":  recent_low5,
        "recent_high5": recent_high5,
        "closes":       closes,
        "highs":        highs,
        "lows":         lows,
        "volumes":      [c["volume"] for c in candles],
    }


# ─────────────────────────────────────────
# SIGNAL DETECTION
# ─────────────────────────────────────────
def check_signal_at(candles, i, ind,
                    ema_consec_rising_min       = EMA_CONSEC_RISING_MIN,
                    ema_slope_pct_min           = EMA_SLOPE_PCT_MIN,
                    ema_slope_pct_min_2candle   = EMA_SLOPE_PCT_MIN_2CANDLE,
                    ema_consec_fall_before_max  = EMA_CONSEC_FALL_BEFORE_MAX,
                    ema_accel_pct_min           = EMA_ACCEL_PCT_MIN,
                    ema9_cross_lookback         = EMA9_CROSS_LOOKBACK,
                    pre_signal_body_candles     = PRE_SIGNAL_BODY_CANDLES,
                    pre_signal_min_body_dom     = PRE_SIGNAL_MIN_BODY_DOM,
                    t1_body_ratio_min           = T1_BODY_RATIO_MIN,
                    consec_green_min            = CONSEC_GREEN_BEFORE_MIN,
                    price_above_ema_min_pct     = PRICE_ABOVE_EMA_MIN_PCT,
                    allow_first_pullback        = ALLOW_FIRST_PULLBACK,
                    first_pullback_t1_roc1_min  = FIRST_PULLBACK_T1_ROC1_MIN,
                    first_pullback_t1_vol_ratio = FIRST_PULLBACK_T1_VOL_RATIO,
                    min_abs_volume              = MIN_ABS_VOLUME,
                    require_positive_roc1       = REQUIRE_POSITIVE_ROC1,
                    vwap_gap_min_pct            = VWAP_GAP_MIN_PCT,
                    vwap_gap_max_pct            = VWAP_GAP_MAX_PCT,
                    min_vol_surge_20            = MIN_VOL_SURGE_20,
                    min_baseline_vol_20         = MIN_BASELINE_VOL_20,
                    vwap_near_cross_pct         = VWAP_NEAR_CROSS_PCT):

    # v9: lowered index guard — EMA20 is context only, not a gate
    if i < INDEX_MIN_CANDLES:
        return False

    ema9    = ind["ema9"]
    ema20   = ind["ema20"]
    closes  = ind["closes"]
    lows    = ind["lows"]
    volumes = ind["volumes"]

    CROSS_MAX_AGE_LOCAL = 40

    vwap_now = float(ind["vwap"][i])
    ema9_now = float(ema9[i])
    if vwap_now <= 0:
        return False

    # ── R1a: EMA9 above VWAP (or within near-cross tolerance) ─────────
    # near_cross: EMA9 is slightly below VWAP but rising hard toward it.
    # Catches VWAP computation drift vs Webull (~0.15-0.5% divergence).
    # Requires: gap > -vwap_near_cross_pct AND consec_rising >= 5 AND slope > 0.1%
    gap_now = (ema9_now - vwap_now) / vwap_now * 100 if vwap_now > 0 else -999
    above_now = ema9_now > vwap_now

    near_cross = False
    if not above_now and gap_now >= -vwap_near_cross_pct:
        # Check that EMA9 is rising hard enough to be credibly crossing
        cr_check = 0
        for j in range(i, max(i-30, 0), -1):
            if j > 0 and float(ema9[j]) > float(ema9[j-1]): cr_check += 1
            else: break
        slope_check = (ema9_now - float(ema9[i-1])) / ema9_now * 100 if i >= 1 and ema9_now > 0 else 0
        if cr_check >= 5 and slope_check > 0.1:
            near_cross = True

    if not above_now and not near_cross:
        return False

    lookback = ema9_cross_lookback if ema9_cross_lookback > 0 else 5

    # Find most recent cross above VWAP
    last_cross_idx = None
    for k in range(i, 0, -1):
        if float(ema9[k]) > float(ind["vwap"][k]) and float(ema9[k-1]) <= float(ind["vwap"][k-1]):
            last_cross_idx = k
            break

    cross_found = False

    if near_cross and last_cross_idx is None:
        # Near-cross with no prior cross detected — treat as the cross itself
        cross_found = True

    elif last_cross_idx is not None:
        candles_since_cross = i - last_cross_idx

        if candles_since_cross <= lookback:
            cross_found = True
        else:
            if candles_since_cross > CROSS_MAX_AGE_LOCAL:
                cross_found = False
            else:
                for k in range(last_cross_idx, i + 1):
                    ema9_k = float(ema9[k])
                    vwap_k = float(ind["vwap"][k])
                    if vwap_k > 0:
                        g = (ema9_k - vwap_k) / vwap_k * 100
                        if g <= CROSS_PROXIMITY_PCT:
                            cross_found = True
                            break

                if not cross_found:
                    # ran-away check
                    if gap_now > 5.0 and candles_since_cross <= CROSS_MAX_AGE_LOCAL:
                        min_gap_since = float('inf')
                        for k in range(last_cross_idx, i + 1):
                            vk = float(ind["vwap"][k])
                            ek = float(ema9[k])
                            if vk > 0:
                                min_gap_since = min(min_gap_since, (ek - vk) / vk * 100)
                        if min_gap_since >= RAN_AWAY_MIN_GAP:
                            cross_found = True

    # near_cross with an existing cross — treat as extension of that cross
    if near_cross and last_cross_idx is not None and not cross_found:
        age = i - last_cross_idx
        if age <= CROSS_MAX_AGE_LOCAL:
            cross_found = True

    if not cross_found:
        return False

    # ── R1c: VWAP proximity gates ─────────────────────────────────
    if vwap_now > 0:
        ema9_vwap_gap_pct = (ema9_now - vwap_now) / vwap_now * 100
        if ema9_vwap_gap_pct < vwap_gap_min_pct:
            return False
        if ema9_vwap_gap_pct > vwap_gap_max_pct:
            return False

    # ── R2: EMA9 consecutively rising ─────────────────────────────
    consec_ema_rising = 0
    for j in range(i, max(i - 30, 0), -1):
        if j > 0 and (ema9[j] - ema9[j-1]) > 0:
            consec_ema_rising += 1
        else:
            break
    if consec_ema_rising < ema_consec_rising_min:
        return False

    # ── R3: EMA9 slope ────────────────────────────────────────────
    ema9_slope     = float(ema9[i]) - float(ema9[i-1])
    ema9_slope_pct = (ema9_slope / float(ema9[i])) * 100 if ema9[i] > 0 else 0
    effective_min  = ema_slope_pct_min_2candle if consec_ema_rising == 2 else ema_slope_pct_min
    if ema9_slope_pct < effective_min:
        return False

    # ── R4: Not recovering from deep downtrend ────────────────────
    consec_fall_before = 0
    fall_start = i - consec_ema_rising - 1
    for j in range(fall_start, max(fall_start - 20, 0), -1):
        if j > 0 and (ema9[j] - ema9[j-1]) < 0:
            consec_fall_before += 1
        else:
            break
    if consec_fall_before > ema_consec_fall_before_max:
        return False

    # ── R5: EMA9 acceleration not sharply fading ─────────────────
    if i >= 2:
        ema9_slope_prev     = float(ema9[i-1]) - float(ema9[i-2])
        ema9_slope_prev_pct = (ema9_slope_prev / float(ema9[i])) * 100 if ema9[i] > 0 else 0
        ema9_accel_pct      = ema9_slope_pct - ema9_slope_prev_pct
        if ema9_accel_pct < ema_accel_pct_min:
            return False

    # ── R8: Price expanding above EMA9 ────────────────────────────
    if ema9[i] <= 0:
        return False
    price_to_ema = (closes[i] - float(ema9[i])) / float(ema9[i]) * 100
    if price_to_ema < price_above_ema_min_pct:
        return False

    # ── R9: Pre-signal body dominance ─────────────────────────────
    body_start = max(0, i - pre_signal_body_candles)
    body_doms  = []
    for j in range(body_start, i):
        o, h, l, c = candles[j]["open"], candles[j]["high"], candles[j]["low"], candles[j]["close"]
        rng = h - l
        if rng > 0:
            body_doms.append(abs(c - o) / rng)
    if body_doms:
        avg_body_dom = sum(body_doms) / len(body_doms)
        if avg_body_dom < pre_signal_min_body_dom:
            return False

    # ── R10: T-1 candle green OR first-pullback ───────────────────
    is_first_pullback = False
    if i >= 1:
        t1_body       = candles[i-1]["close"] - candles[i-1]["open"]
        signal_is_red = (candles[i]["close"] - candles[i]["open"]) < 0

        if signal_is_red and allow_first_pullback and i >= 2:
            t1_roc1    = (candles[i-1]["close"] - candles[i-2]["close"]) / candles[i-2]["close"] * 100 \
                         if candles[i-2]["close"] > 0 else 0
            vol_window = [candles[k]["volume"] for k in range(max(0, i-10), i-1)]
            vol_avg    = sum(vol_window) / len(vol_window) if vol_window else 0
            if t1_roc1 >= first_pullback_t1_roc1_min and vol_avg > 0 and \
               candles[i-1]["volume"] >= first_pullback_t1_vol_ratio * vol_avg:
                is_first_pullback = True

        if not is_first_pullback:
            if T1_MUST_BE_GREEN and t1_body <= 0:
                return False
    elif T1_MUST_BE_GREEN:
        return False

    # ── R11: T-1 body ratio ───────────────────────────────────────
    if t1_body_ratio_min > 0 and i >= 1 and not is_first_pullback:
        t1_abs_body = abs(candles[i-1]["close"] - candles[i-1]["open"])
        avg_body    = float(ind["body_ma10"][i-1])
        t1_ratio_ok = avg_body > 0 and (t1_abs_body / avg_body) >= t1_body_ratio_min

        vol_window_20    = [candles[k]["volume"] for k in range(max(0, i-20), i)]
        vol_avg_20       = sum(vol_window_20) / len(vol_window_20) if vol_window_20 else 1
        signal_vol_surge = candles[i]["volume"] / vol_avg_20 if vol_avg_20 > 0 else 0
        vol_surge_bypass = signal_vol_surge >= 3.0

        if not t1_ratio_ok and not vol_surge_bypass:
            return False

    # ── R12: Consecutive green candles before signal ──────────────
    consec_green = 0
    for j in range(i - 1, max(i - 15, -1), -1):
        if j < 0:
            break
        if candles[j]["close"] > candles[j]["open"]:
            consec_green += 1
        else:
            break
    if consec_green < consec_green_min:
        return False

    # ── R13: Price not breaking 5-candle low — HARD LOCK ──────────
    if not BROKE_LOW5_ALLOWED and i > 0:
        if lows[i] < float(ind["recent_low5"][i-1]):
            return False

    # ── R14: ROC1 context only ────────────────────────────────────
    if require_positive_roc1 and not is_first_pullback and i > 0:
        if closes[i] < closes[i-1]:
            return False

    # ── R15: Minimum absolute volume — HARD LOCK ──────────────────
    if volumes[i] < min_abs_volume:
        return False

    # ── R16: Volume surge ─────────────────────────────────────────
    vol_window_r16   = [candles[k]["volume"] for k in range(max(0, i-20), i)]
    vol_avg_r16      = sum(vol_window_r16) / len(vol_window_r16) if vol_window_r16 else 1
    actual_surge_r16 = volumes[i] / vol_avg_r16 if vol_avg_r16 > 0 else 0

    # NEW R16b: baseline volume floor — avg20 must be >= MIN_BASELINE_VOL_20
    # Blocks deep premarket noise where the 20-candle avg is essentially zero.
    # HCTI 4:34 had avg20=6,687 — all valid signals had avg20 >> 10k.
    if vol_avg_r16 < min_baseline_vol_20:
        return False

    vwap_gap_r16    = (float(ema9[i]) - float(ind["vwap"][i])) / float(ind["vwap"][i]) * 100 \
                      if float(ind["vwap"][i]) > 0 else 0
    surge_threshold = 1.0 if vwap_gap_r16 > 8.0 else min_vol_surge_20
    if vol_avg_r16 > 0 and actual_surge_r16 < surge_threshold:
        return False

    return True


# ─────────────────────────────────────────
# SCAN ONE TICKER FOR ONE DAY
# ─────────────────────────────────────────
def scan_day(ticker, date, candles,
             ema_consec_rising_min       = EMA_CONSEC_RISING_MIN,
             ema_slope_pct_min           = EMA_SLOPE_PCT_MIN,
             ema_slope_pct_min_2candle   = EMA_SLOPE_PCT_MIN_2CANDLE,
             ema_consec_fall_before_max  = EMA_CONSEC_FALL_BEFORE_MAX,
             ema_accel_pct_min           = EMA_ACCEL_PCT_MIN,
             ema9_cross_lookback         = EMA9_CROSS_LOOKBACK,
             pre_signal_body_candles     = PRE_SIGNAL_BODY_CANDLES,
             pre_signal_min_body_dom     = PRE_SIGNAL_MIN_BODY_DOM,
             t1_body_ratio_min           = T1_BODY_RATIO_MIN,
             consec_green_min            = CONSEC_GREEN_BEFORE_MIN,
             price_above_ema_min_pct     = PRICE_ABOVE_EMA_MIN_PCT,
             allow_first_pullback        = ALLOW_FIRST_PULLBACK,
             first_pullback_t1_roc1_min  = FIRST_PULLBACK_T1_ROC1_MIN,
             first_pullback_t1_vol_ratio = FIRST_PULLBACK_T1_VOL_RATIO,
             min_abs_volume              = MIN_ABS_VOLUME,
             cooldown_minutes            = COOLDOWN_MINUTES,
             require_positive_roc1       = REQUIRE_POSITIVE_ROC1,
             vwap_gap_min_pct            = VWAP_GAP_MIN_PCT,
             vwap_gap_max_pct            = VWAP_GAP_MAX_PCT,
             min_vol_surge_20            = MIN_VOL_SURGE_20,
             min_baseline_vol_20         = MIN_BASELINE_VOL_20,
             vwap_near_cross_pct         = VWAP_NEAR_CROSS_PCT):

    signals          = []
    last_signal_time = None
    ind              = calculate_indicators(candles)

    for i in range(len(candles)):
        ct = candles[i]["time"]
        if not is_valid_time(ct.time()):
            continue

        if last_signal_time is not None:
            if (ct - last_signal_time).total_seconds() / 60 < cooldown_minutes:
                continue

        if check_signal_at(candles, i, ind,
                           ema_consec_rising_min=ema_consec_rising_min,
                           ema_slope_pct_min=ema_slope_pct_min,
                           ema_slope_pct_min_2candle=ema_slope_pct_min_2candle,
                           ema_consec_fall_before_max=ema_consec_fall_before_max,
                           ema_accel_pct_min=ema_accel_pct_min,
                           ema9_cross_lookback=ema9_cross_lookback,
                           pre_signal_body_candles=pre_signal_body_candles,
                           pre_signal_min_body_dom=pre_signal_min_body_dom,
                           t1_body_ratio_min=t1_body_ratio_min,
                           consec_green_min=consec_green_min,
                           price_above_ema_min_pct=price_above_ema_min_pct,
                           allow_first_pullback=allow_first_pullback,
                           first_pullback_t1_roc1_min=first_pullback_t1_roc1_min,
                           first_pullback_t1_vol_ratio=first_pullback_t1_vol_ratio,
                           min_abs_volume=min_abs_volume,
                           require_positive_roc1=require_positive_roc1,
                           vwap_gap_min_pct=vwap_gap_min_pct,
                           vwap_gap_max_pct=vwap_gap_max_pct,
                           min_vol_surge_20=min_vol_surge_20,
                           min_baseline_vol_20=min_baseline_vol_20,
                           vwap_near_cross_pct=vwap_near_cross_pct):

            last_signal_time = ct

            ema9_val       = float(ind["ema9"][i])
            ema20_val      = float(ind["ema20"][i])
            vwap_val       = float(ind["vwap"][i])
            ema9_slope     = float(ind["ema9"][i]) - float(ind["ema9"][i-1])
            ema9_slope_pct = round((ema9_slope / ema9_val) * 100, 5) if ema9_val > 0 else 0
            ema9_accel     = round(float((ind["ema9"][i] - ind["ema9"][i-1]) - (ind["ema9"][i-1] - ind["ema9"][i-2])), 6) if i >= 2 else 0
            roc1           = round((candles[i]["close"] - candles[i-1]["close"]) / candles[i-1]["close"] * 100, 2) if i >= 1 else 0
            roc3           = round((candles[i]["close"] - candles[i-3]["close"]) / candles[i-3]["close"] * 100, 2) if i >= 3 else 0
            p_to_ema       = round((candles[i]["close"] - ema9_val) / ema9_val * 100, 2)
            ema9_ema20_gap = round((ema9_val - ema20_val) / ema20_val * 100, 3) if ema20_val > 0 else 0
            ema9_vwap_gap  = round((ema9_val - vwap_val)  / vwap_val  * 100, 3) if vwap_val  > 0 else 0

            ema9_above_ema20_run = 0
            for j in range(i - 1, max(i - 60, 0), -1):
                if float(ind["ema9"][j]) > float(ind["ema20"][j]):
                    ema9_above_ema20_run += 1
                else:
                    break

            body_start = max(0, i - pre_signal_body_candles)
            body_doms  = []
            for j in range(body_start, i):
                o, h, l, c = candles[j]["open"], candles[j]["high"], candles[j]["low"], candles[j]["close"]
                rng = h - l
                if rng > 0:
                    body_doms.append(abs(c - o) / rng)
            avg_body_dom = round(sum(body_doms) / len(body_doms), 3) if body_doms else 0

            t1_abs_body   = round(abs(candles[i-1]["close"] - candles[i-1]["open"]), 4) if i >= 1 else 0
            t1_body_avg   = round(float(ind["body_ma10"][i-1]), 4) if i >= 1 else 0
            t1_body_ratio = round(t1_abs_body / t1_body_avg, 3) if t1_body_avg > 0 else 0

            consec_g = 0
            for j in range(i-1, max(i-15,-1), -1):
                if j < 0: break
                if candles[j]["close"] > candles[j]["open"]: consec_g += 1
                else: break

            consec_ema = 0
            for j in range(i, max(i-30,0), -1):
                if j > 0 and (ind["ema9"][j] - ind["ema9"][j-1]) > 0: consec_ema += 1
                else: break

            consec_fall = 0
            fall_start  = i - consec_ema - 1
            for j in range(fall_start, max(fall_start - 20, 0), -1):
                if j > 0 and (ind["ema9"][j] - ind["ema9"][j-1]) < 0: consec_fall += 1
                else: break

            vol_window_20 = [candles[k]["volume"] for k in range(max(0, i-20), i)]
            vol_avg_20    = sum(vol_window_20) / len(vol_window_20) if vol_window_20 else 1
            vol_surge     = round(candles[i]["volume"] / vol_avg_20, 2) if vol_avg_20 > 0 else 0

            range_now     = candles[i]["high"] - candles[i]["low"]
            ranges_10     = [candles[k]["high"] - candles[k]["low"] for k in range(max(0, i-10), i)]
            range_avg_10  = sum(ranges_10) / len(ranges_10) if ranges_10 else 1
            range_exp     = round(range_now / range_avg_10, 2) if range_avg_10 > 0 else 0

            signal_is_red = (candles[i]["close"] - candles[i]["open"]) < 0
            t1_roc1_out   = round((candles[i-1]["close"] - candles[i-2]["close"]) / candles[i-2]["close"] * 100, 2) \
                            if i >= 2 and candles[i-2]["close"] > 0 else 0
            vol_window    = [candles[k]["volume"] for k in range(max(0, i-10), i-1)]
            vol_avg       = sum(vol_window) / len(vol_window) if vol_window else 1
            fp_flag       = (signal_is_red and allow_first_pullback and
                             t1_roc1_out >= first_pullback_t1_roc1_min and
                             candles[i-1]["volume"] >= first_pullback_t1_vol_ratio * vol_avg) if i >= 2 else False

            ema5_slope_pct = round((float(ind["ema5"][i]) - float(ind["ema5"][i-1])) / float(ind["ema5"][i]) * 100, 5) \
                             if i > 0 and float(ind["ema5"][i]) > 0 else 0

            signals.append({
                "ticker":                   ticker,
                "date":                     date,
                "time":                     ct.strftime("%I:%M %p"),
                "close":                    round(candles[i]["close"], 4),
                "volume":                   candles[i]["volume"],
                "vol_surge_ratio":          vol_surge,
                "range_expansion_ratio":    range_exp,
                "ema9":                     round(ema9_val, 5),
                "ema20":                    round(ema20_val, 5),
                "vwap":                     round(vwap_val, 5),
                "ema9_ema20_gap_pct":       ema9_ema20_gap,
                "ema9_vwap_gap_pct":        ema9_vwap_gap,
                "ema9_above_ema20_candles": ema9_above_ema20_run,
                "ema9_slope_pct":           ema9_slope_pct,
                "ema9_accel":               ema9_accel,
                "ema5_slope_pct":           ema5_slope_pct,
                "ema_consec_rising":        consec_ema,
                "ema_consec_fall_before":   consec_fall,
                "price_to_ema_pct":         p_to_ema,
                "avg_body_dom":             avg_body_dom,
                "t1_body_ratio":            t1_body_ratio,
                "consec_green_before":      consec_g,
                "roc1":                     roc1,
                "roc3":                     roc3,
                "first_pullback":           fp_flag,
                "window":                   "Premarket" if ct.time() <= time(9, 19) else "Session",
            })

    return signals


# ─────────────────────────────────────────
# RUN BACKTEST (CLI)
# ─────────────────────────────────────────
def run_backtest(days=1):
    trading_days = get_last_trading_days(days)
    all_signals  = []

    print("\n" + "="*60)
    print("  BACKTEST  v9.0  —  VWAP Cross Signal System")
    print(f"  R8:  price_above_ema  >= {PRICE_ABOVE_EMA_MIN_PCT}%  (was 1.0)")
    print(f"  R11: t1_body_ratio    >= {T1_BODY_RATIO_MIN}x   (was 0.7)")
    print(f"  R16: vol_surge        >= {MIN_VOL_SURGE_20}x   (was 2.0)")
    print(f"  R16b: baseline_vol_20 >= {MIN_BASELINE_VOL_20:,}  (NEW)")
    print(f"  R1a: near_cross_pct   <= {VWAP_NEAR_CROSS_PCT}% below VWAP (NEW)")
    print(f"  Time window: 6:30am-9:19am premarket, 9:35am-1pm session")
    print(f"  Index guard: >= {INDEX_MIN_CANDLES} candles  (was ~23)")
    print("="*60 + "\n")

    for date in trading_days:
        print(f"── {date} ──────────────────────────────")
        day_signals = []
        for ticker in STOCK_POOL:
            candles = get_candles(ticker, date)
            if not candles:
                print(f"  {ticker}: no data")
                continue
            signals = scan_day(ticker, date, candles)
            if signals:
                for s in signals:
                    print(f"  SIGNAL{'[FP]' if s.get('first_pullback') else '    '}  {s['ticker']:6s}  {s['time']}  "
                          f"${s['close']}  "
                          f"vwap_gap={s['ema9_vwap_gap_pct']:+.3f}%  "
                          f"slope={s['ema9_slope_pct']:+.4f}%  "
                          f"vol_surge={s['vol_surge_ratio']}x  "
                          f"roc1={s['roc1']:+.2f}%  [{s['window']}]")
                day_signals.extend(signals)
            else:
                print(f"  {ticker}: no signal")

        if not day_signals:
            print("  No signals found this day.")
        all_signals.extend(day_signals)
        print()

    if all_signals:
        pd.DataFrame(all_signals).to_csv("backtest_results.csv", index=False)
        print(f"\n{len(all_signals)} signals saved to backtest_results.csv")
    else:
        print("\nNo signals found.")
    print("\n" + "="*60 + "\n")

if __name__ == "__main__":
    run_backtest()