"""
DAILY MOVERS WATCHER — Flask App  v1
══════════════════════════════════════════════════════
Runs the Finviz watcher in a background thread.
Every scan records a "sighting" for each ticker seen.

CSV exports ONE ROW PER UNIQUE TICKER with:
  ticker, date, times_seen, first_seen, last_seen,
  avg_price, min_price, max_price, avg_change_pct
"""

from flask import Flask, render_template, jsonify, request
import threading
import csv
import os
import time as ttime
from datetime import datetime
import pytz

from dailymoverscanner import (
    get_finviz_movers,
    in_window,
    ET,
    MAX_PRICE,
    MIN_CHANGE_PCT,
    SCAN_INTERVAL_SEC,
    WINDOW_START,
    WINDOW_END,
)

app = Flask(__name__)

# ─────────────────────────────────────────
# SHARED STATE
# ─────────────────────────────────────────
state = {
    "running":       False,
    "sightings":     [],
    "pool":          [],
    "last_scan":     None,
    "scan_count":    0,
    "csv_path":      None,
    "run_id":        None,
    "export_status": "No export yet",
}

state_lock     = threading.Lock()
watcher_thread = None
export_thread  = None


# ─────────────────────────────────────────
# CSV HELPERS
# ─────────────────────────────────────────
EXPORT_ROOT = "Mover Watch Exports"
CSV_COLUMNS = [
    "run_id", "date", "ticker", "times_seen",
    "first_seen", "last_seen",
    "avg_price", "min_price", "max_price", "avg_change_pct",
]


def _resolve_csv(start_dt):
    date_str = start_dt.strftime("%Y-%m-%d")
    time_str = start_dt.strftime("%H-%M-%S")
    day_dir  = os.path.join(EXPORT_ROOT, date_str)
    os.makedirs(day_dir, exist_ok=True)
    return os.path.join(day_dir, f"watch_{time_str}.csv")


def _init_csv(path):
    if not os.path.exists(path):
        with open(path, "w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=CSV_COLUMNS).writeheader()


def _build_unique_rows(sightings, run_id):
    seen = {}
    for s in sightings:
        tk = s["ticker"]
        if tk not in seen:
            seen[tk] = {
                "ticker":     tk,
                "date":       s["date"],
                "times_seen": 0,
                "prices":     [],
                "changes":    [],
                "first_seen": s["scan_time"],
                "last_seen":  s["scan_time"],
            }
        seen[tk]["times_seen"] += 1
        seen[tk]["prices"].append(s["price"])
        seen[tk]["changes"].append(s["change_pct"])
        seen[tk]["last_seen"] = s["scan_time"]

    rows = []
    for t in sorted(seen.values(), key=lambda x: -x["times_seen"]):
        rows.append({
            "run_id":         run_id,
            "date":           t["date"],
            "ticker":         t["ticker"],
            "times_seen":     t["times_seen"],
            "first_seen":     t["first_seen"],
            "last_seen":      t["last_seen"],
            "avg_price":      round(sum(t["prices"])  / len(t["prices"]),  4),
            "min_price":      round(min(t["prices"]), 4),
            "max_price":      round(max(t["prices"]), 4),
            "avg_change_pct": round(sum(t["changes"]) / len(t["changes"]), 2),
        })
    return rows


def _write_csv(path, sightings, run_id):
    rows = _build_unique_rows(sightings, run_id)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def _flush_csv():
    with state_lock:
        path      = state["csv_path"]
        run_id    = state["run_id"]
        sightings = list(state["sightings"])
    if not path or not run_id:
        return
    try:
        n  = _write_csv(path, sightings, run_id)
        ts = datetime.now(ET).strftime("%I:%M:%S %p")
        with state_lock:
            state["export_status"] = f"Last export: {ts}  ({n} unique tickers)  →  {path}"
    except Exception as exc:
        with state_lock:
            state["export_status"] = f"Export error: {exc}"


# ─────────────────────────────────────────
# EXPORT THREAD
# ─────────────────────────────────────────
def export_loop():
    _flush_csv()
    while state["running"]:
        ttime.sleep(300)
        if not state["running"]:
            break
        _flush_csv()
    _flush_csv()


# ─────────────────────────────────────────
# WATCHER THREAD
# ─────────────────────────────────────────
def watcher_loop():
    while state["running"]:
        now_et   = datetime.now(ET)
        now_time = now_et.time()

        if not in_window(now_time):
            with state_lock:
                state["last_scan"] = now_et.strftime("%I:%M:%S %p") + "  (outside window)"
            ttime.sleep(30)
            continue

        movers   = get_finviz_movers()
        scan_ts  = now_et.strftime("%I:%M:%S %p")
        date_str = now_et.strftime("%Y-%m-%d")

        new_sightings = []
        pool_tickers  = []

        for m in movers:
            pool_tickers.append(m["ticker"])
            new_sightings.append({
                "ticker":     m["ticker"],
                "price":      m["price"],
                "change_pct": m["change_pct"],
                "scan_time":  scan_ts,
                "date":       date_str,
            })

        with state_lock:
            state["sightings"].extend(new_sightings)
            state["pool"]       = pool_tickers
            state["last_scan"]  = scan_ts
            state["scan_count"] += 1

        ttime.sleep(SCAN_INTERVAL_SEC)


# ─────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────
@app.route("/")
def index():
    return render_template("dailymoverindex.html")


@app.route("/start", methods=["POST"])
def start_watcher():
    global watcher_thread, export_thread

    if state["running"]:
        return jsonify({"status": "already_running"})

    now_et   = datetime.now(ET)
    run_id   = now_et.strftime("run_%Y-%m-%d_%H-%M-%S")
    csv_path = _resolve_csv(now_et)
    _init_csv(csv_path)

    with state_lock:
        state["running"]       = True
        state["sightings"]     = []
        state["pool"]          = []
        state["last_scan"]     = None
        state["scan_count"]    = 0
        state["csv_path"]      = csv_path
        state["run_id"]        = run_id
        state["export_status"] = f"CSV created → {csv_path}"

    watcher_thread = threading.Thread(target=watcher_loop, daemon=True)
    export_thread  = threading.Thread(target=export_loop,  daemon=True)
    watcher_thread.start()
    export_thread.start()

    return jsonify({
        "status":   "started",
        "run_id":   run_id,
        "csv_path": csv_path,
        "window":   f"{WINDOW_START.strftime('%I:%M %p')} – {WINDOW_END.strftime('%I:%M %p')} ET",
        "filters":  f"price < ${MAX_PRICE}  |  change >= {MIN_CHANGE_PCT}%",
    })


@app.route("/stop", methods=["POST"])
def stop_watcher():
    state["running"] = False
    return jsonify({"status": "stopped"})


@app.route("/status")
def status():
    with state_lock:
        seen = {}
        for s in state["sightings"]:
            tk = s["ticker"]
            if tk not in seen:
                seen[tk] = {
                    "ticker":      tk,
                    "times_seen":  0,
                    "prices":      [],
                    "changes":     [],
                    "first_seen":  s["scan_time"],
                    "last_seen":   s["scan_time"],
                    "last_price":  s["price"],
                    "last_change": s["change_pct"],
                }
            seen[tk]["times_seen"] += 1
            seen[tk]["prices"].append(s["price"])
            seen[tk]["changes"].append(s["change_pct"])
            seen[tk]["last_seen"]   = s["scan_time"]
            seen[tk]["last_price"]  = s["price"]
            seen[tk]["last_change"] = s["change_pct"]

        ticker_summary = sorted(seen.values(), key=lambda x: -x["times_seen"])
        for t in ticker_summary:
            t["avg_price"]  = round(sum(t["prices"])  / len(t["prices"]),  4)
            t["avg_change"] = round(sum(t["changes"]) / len(t["changes"]), 2)
            t["min_price"]  = round(min(t["prices"]), 4)
            t["max_price"]  = round(max(t["prices"]), 4)
            del t["prices"], t["changes"]

        return jsonify({
            "running":          state["running"],
            "pool":             state["pool"],
            "pool_size":        len(state["pool"]),
            "last_scan":        state["last_scan"],
            "scan_count":       state["scan_count"],
            "total_sightings":  len(state["sightings"]),
            "unique_tickers":   len(seen),
            "ticker_summary":   ticker_summary,
            "recent_sightings": list(reversed(state["sightings"][-200:])),
            "csv_path":         state["csv_path"],
            "run_id":           state["run_id"],
            "export_status":    state["export_status"],
        })


@app.route("/clear", methods=["POST"])
def clear():
    with state_lock:
        state["sightings"]  = []
        state["pool"]       = []
        state["scan_count"] = 0
    _flush_csv()
    return jsonify({"status": "cleared"})


@app.route("/export_now", methods=["POST"])
def export_now():
    _flush_csv()
    with state_lock:
        return jsonify({
            "status":        "exported",
            "export_status": state["export_status"],
            "csv_path":      state["csv_path"],
        })


if __name__ == "__main__":
    app.run(debug=True, port=5002)