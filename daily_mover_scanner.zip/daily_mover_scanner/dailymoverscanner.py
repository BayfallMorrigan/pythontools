"""
DAILY MOVERS WATCHER  —  v1
════════════════════════════════════════════════════
Purpose:
  Sit in the market from 4:30 AM to 12:00 PM ET and
  record every ticker that appears on Finviz's top-gainers
  list while priced under $30.

What it captures per sighting:
  · ticker, price, % change, scan time

No candle data. No signals. No indicators.
Just: "was this ticker on the movers list at this moment?"

Pool filters:
  · Price  < MAX_PRICE      ($30)
  · Change > MIN_CHANGE_PCT (5%)
  · Pool capped at MAX_POOL_SIZE tickers

Scan window:   4:30 AM – 12:00 PM ET
Scan interval: every SCAN_INTERVAL_SEC seconds (default 60)
"""

import requests
from bs4 import BeautifulSoup
from datetime import datetime, time
import pytz
import time as ttime

ET = pytz.timezone("America/New_York")

# ─────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────
MAX_PRICE         = 30.0
MIN_CHANGE_PCT    = 5.0
MAX_POOL_SIZE     = 40
SCAN_INTERVAL_SEC = 60

WINDOW_START = time(4, 30)
WINDOW_END   = time(12, 0)


# ─────────────────────────────────────────
# TIME GATE
# ─────────────────────────────────────────
def in_window(t: time) -> bool:
    return WINDOW_START <= t <= WINDOW_END


# ─────────────────────────────────────────
# FINVIZ SCRAPE
# Returns list of dicts: { ticker, price, change_pct }
# ─────────────────────────────────────────
def get_finviz_movers():
    try:
        url = (
            f"https://finviz.com/screener.ashx?v=111&s=ta_topgainers"
            f"&f=sh_price_u{int(MAX_PRICE)}&o=-change"
        )
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            )
        }
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()

        soup   = BeautifulSoup(resp.text, "html.parser")
        movers = []
        rows   = soup.select("tr.styled-row")
        if not rows:
            rows = soup.select("table#screener-content tr")

        for row in rows:
            cells = row.find_all("td")
            if len(cells) < 10:
                continue
            try:
                ticker = cells[1].get_text(strip=True)
                price  = float(cells[8].get_text(strip=True).replace(",", ""))
                change = float(cells[9].get_text(strip=True).replace("%", "").replace(",", ""))
                if price < MAX_PRICE and change >= MIN_CHANGE_PCT:
                    movers.append({
                        "ticker":     ticker,
                        "price":      round(price, 4),
                        "change_pct": round(change, 2),
                    })
                    if len(movers) >= MAX_POOL_SIZE:
                        break
            except (ValueError, IndexError):
                continue

        return movers

    except Exception as e:
        print(f"  [Finviz error] {e}")
        return []


# ─────────────────────────────────────────
# STANDALONE LOOP (optional — not used by dailymoverapp.py)
# ─────────────────────────────────────────
def run_watcher():
    print("\n" + "=" * 60)
    print("  DAILY MOVERS WATCHER  v1")
    print(f"  Window  : {WINDOW_START.strftime('%I:%M %p')} – {WINDOW_END.strftime('%I:%M %p')} ET")
    print(f"  Filter  : price < ${MAX_PRICE}  |  change >= {MIN_CHANGE_PCT}%")
    print(f"  Interval: {SCAN_INTERVAL_SEC}s")
    print("=" * 60 + "\n")

    while True:
        now_et   = datetime.now(ET)
        now_time = now_et.time()

        if not in_window(now_time):
            print(f"  Outside window — {now_et.strftime('%I:%M %p')} ET. Sleeping 60s...")
            ttime.sleep(60)
            continue

        scan_ts = now_et.strftime("%I:%M:%S %p")
        movers  = get_finviz_movers()
        print(f"  [{scan_ts}] Found {len(movers)} movers:")
        for m in movers:
            print(f"    {m['ticker']:8s}  ${m['price']:.2f}  +{m['change_pct']:.1f}%")

        ttime.sleep(SCAN_INTERVAL_SEC)


if __name__ == "__main__":
    run_watcher()