DAILY MOVER SCANNER
===================

REQUIREMENTS
------------
- Python must be installed on your computer
  Download: https://www.python.org/downloads/
  (Check "Add Python to PATH" during install)

HOW TO RUN
----------
1. Extract this zip folder anywhere on your computer
2. Double-click start.bat
3. Browser will open automatically to the app

That's it!

NOTES
-----
- The app runs on http://localhost:5002
- Scans Finviz for top gainers under $30 with 5%+ change
- Active scan window: 4:30 AM to 12:00 PM ET
- CSV exports save to "Mover Watch Exports" folder
- To stop the app, close the terminal window that opens

TROUBLESHOOTING
---------------
- If browser doesn't open, manually go to http://localhost:5002
- If you get a pip error, open a terminal and run:
    pip install flask requests beautifulsoup4 pytz
  Then double-click start.bat again
